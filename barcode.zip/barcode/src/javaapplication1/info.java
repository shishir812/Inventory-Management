package javaapplication1;
public class info {
   public String category;
   public String productName;
   public int number_of_items;
   public int unit;
   public int total_cost;   
}
