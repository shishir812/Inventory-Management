package javaapplication1;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.ListSelectionModel;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.table.DefaultTableModel;
public class NewJFrame extends javax.swing.JFrame {
    Scanner input = new Scanner(System.in);
    private  Connection con;
    private Statement st;
    private ResultSet rs;
    String cat;
     String p_name;
    PreparedStatement prepStmt = null;
   public double total_cost=0; 
   int getRowId=0;
   double sold_items=0;
   double remaining_items=0;
   String client_name="exci04wk";

    String name;
    double checker;
    Date now = new Date();
    Calendar cal = Calendar.getInstance();
    DefaultTableModel model;
    double  items_number=0;
    double price_unit=0;
    
    //------------------------------------------Constructor InitializatioN---------------------------
    public NewJFrame() {
       /* try{
          Class.forName("com.mysql.jdbc.Driver");
          con=DriverManager.getConnection("jdbc:mysql://localhost/shopmanagemant","root","");
          st=con.createStatement(); 
         
      }catch(Exception ex){
          System.out.println("Error:"+ex);
      }
        initComponents();
        model =(DefaultTableModel)  tblProduct.getModel();
       String node=(String) cbCategory.getSelectedItem();
        
        if(node.equals("IceCream")){
           iceCream();
        }*/
        
        
    }
    public void iceCream(){
        try{
            //   Daysearch day =new Daysearch();
            String query="select *  from icecream";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName")
                String yr=rs.getString("productName");
                
                jTextField1.addItem(yr);
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }
    
    ///---------Inserting Admin Table valuses----------
    public void inserInToAdmin(){
  int YEAR = Calendar.getInstance().get(Calendar.YEAR);
  int MONTH = Calendar.getInstance().get(Calendar.MONTH)+1;
  int DAY_OF_MONTH = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
  
  String strYear=Integer.toString(YEAR);
  String strMonth=Integer.toString(MONTH);
  String strDay=Integer.toString(DAY_OF_MONTH );
  java.util.Date dt = new java.util.Date();
  java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("hh:mm:ss a");
  String currentTime = sdf.format(dt);
  String t_cost=Double.toString(total_cost);
  try{
       String query2="INSERT INTO admintable(day,month,year,time,clientName,cost) VALUES(?,?,?,?,?,?)";
                prepStmt = con.prepareStatement(query2);
                prepStmt.setString(1,strDay);
                prepStmt.setString(2,strMonth);
                prepStmt.setString(3,strYear);
                prepStmt.setString(4,currentTime);
                prepStmt.setString(5,client_name);
                prepStmt.setString(6,t_cost);
                prepStmt.executeUpdate();
                System.out.println("okY");
               
  }catch(Exception e){
      System.out.println("e:"+e);
  }
  
    }
    //---------------------//--------------------//------------
    public void passValue(){
        String x="",y="";double z=0;
        FinalForm ff=new FinalForm();
        double p=0,q=0;
        int arr[]=new int[9];
        
            for (int i = 0; i < tblProduct.getRowCount(); i++) {
             Object a[] = new Object[5];   
  for (int j = 0; j < 5; j++) {
      if(j==0)
      {
        x= (String)tblProduct.getValueAt(i, j);
        
        //(o instanceof String)
      }
      if(j==1)
      {
         y= (String)tblProduct.getValueAt(i, j); 
      }
      if(j==2)
      {
          z= (Double)tblProduct.getValueAt(i, j);
          
      }   
      if(j==3){
         p=(Double) tblProduct.getValueAt(i, j);
      }
      if(j==4){
          q=(Double) tblProduct.getValueAt(i, j);
      }
   
  }
              //  System.out.println("x:"+x+" y:"+y+" z:"+z+" p:"+p+" q:"+q);
                DefaultTableModel model=(DefaultTableModel) FinalForm.final_table.getModel();
                 model.addRow(new Object[]{x,y,z,p,q});
 
               
            }
            java.util.Date dt = new java.util.Date();
    java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd-MMM-yyyy HH:mm:ss a");
    String currentT = sdf.format(dt);
            String cast=Double.toString(total_cost);
            FinalForm.name.setText("Name: "+clientName.getText());
            FinalForm.phone.setText("PhnNumber: "+clientNumber.getText());
            FinalForm.address.setText("Address: "+clientAddress.getText());
            FinalForm.datime.setText("Date/Time: "+currentT);
            FinalForm.bill.setText("Total Bill: "+cast+"  taka");
            ff.setVisible(true);
    }
    ///getData Method to get data from my jtable at the end-----------------------------------------------------------------
    public void ss(){
         try{
        ArrayList<ProductUpdateModel> aList = new ArrayList<ProductUpdateModel>();
        
        String x="",y="";double z=0;
        int arr[]=new int[9];
        
            for (int i = 0; i < tblProduct.getRowCount(); i++) {
             Object a[] = new Object[3];   
  for (int j = 0; j < 3; j++) {
      if(j==0)
      {
        x= (String)tblProduct.getValueAt(i, j);
        
        //(o instanceof String)
      }
      if(j==1)
      {
         y= (String)tblProduct.getValueAt(i, j); 
      }
      if(j==2)
      {
          z= (Double)tblProduct.getValueAt(i, j);
          
      }   
   
  }
  // System.out.println("x:"+x+" y:"+y+" z:"+z);
  if(y.equals("IceCream")){
      try{

                String query="select sold,crrentStatus  from icecream where productName=? ";
                prepStmt = con.prepareStatement(query);
                prepStmt.setString(1,x);
                rs=prepStmt.executeQuery();
                while(rs.next()){
                    // pname=rs.getString("pName");
                    
                    String m=rs.getString("sold");
                    String n=rs.getString("crrentStatus");
                    sold_items=Double.parseDouble(m)+z;
                    remaining_items=Double.parseDouble(n)-z;
                   
                    //System.out.println("sold:"+sold_items+" Remain:"+remaining_items);
                }   

            }catch(Exception e){
                System.out.println("Roor:"+e);
            }
      try{
          String crnt=Double.toString(remaining_items);
          String sld=Double.toString(sold_items);
          System.out.println("crnt:"+crnt+" sld:"+sld);
               String query="update icecream set crrentStatus = ?,sold=? where  productName= ?";
            prepStmt = con.prepareStatement(query);
            prepStmt.setString(1,crnt);
            prepStmt.setString(2,sld);
            prepStmt.setString(3,x);
            prepStmt.executeUpdate();
               message.setText("ok");
           }catch(Exception e){
               message.setText("Error:"+e);
               System.out.println(""+e);
           }
      
      
  }else if(y.equals("Fish")){
      try{

                String query="select solditems,currentStatus  from fish where productName=? ";
                prepStmt = con.prepareStatement(query);
                prepStmt.setString(1,x);
                rs=prepStmt.executeQuery();
                while(rs.next()){
                    // pname=rs.getString("pName");
                    
                    String m=rs.getString("solditems");
                    String n=rs.getString("currentStatus");
                    sold_items=Double.parseDouble(m)+z;
                    remaining_items=Double.parseDouble(n)-z;
                   
                    //System.out.println("sold:"+sold_items+" Remain:"+remaining_items);
                }   

            }catch(Exception e){
                System.out.println("Roor:"+e);
            }
      try{
          String crnt=Double.toString(remaining_items);
          String sld=Double.toString(sold_items);
          System.out.println("crnt:"+crnt+" sld:"+sld);
               String query="update fish set currentStatus = ?,solditems=? where  productName= ?";
            prepStmt = con.prepareStatement(query);
            prepStmt.setString(1,crnt);
            prepStmt.setString(2,sld);
            prepStmt.setString(3,x);
            prepStmt.executeUpdate();
               message.setText("ok fish");
           }catch(Exception e){
               message.setText("Error:"+e);
               System.out.println(""+e);
           }
      
      
  }else if(y.equals("Meat")){
      try{

                String query="select solditems,currentStatus  from meat where productName=? ";
                prepStmt = con.prepareStatement(query);
                prepStmt.setString(1,x);
                rs=prepStmt.executeQuery();
                while(rs.next()){
                    // pname=rs.getString("pName");
                    
                    String m=rs.getString("solditems");
                    String n=rs.getString("currentStatus");
                    sold_items=Double.parseDouble(m)+z;
                    remaining_items=Double.parseDouble(n)-z;
                   
                    //System.out.println("sold:"+sold_items+" Remain:"+remaining_items);
                }   

            }catch(Exception e){
                System.out.println("Roor:"+e);
            }
      try{
          String crnt=Double.toString(remaining_items);
          String sld=Double.toString(sold_items);
          System.out.println("crnt:"+crnt+" sld:"+sld);
               String query="update meat set currentStatus = ?,solditems=? where  productName= ?";
            prepStmt = con.prepareStatement(query);
            prepStmt.setString(1,crnt);
            prepStmt.setString(2,sld);
            prepStmt.setString(3,x);
            prepStmt.executeUpdate();
               message.setText("ok meat");
           }catch(Exception e){
               message.setText("Error:"+e);
               System.out.println(""+e);
           }
      
  }else if(y.equals("Vegetables")){
      try{

                String query="select solditems,currentStatus  from vegetables where productName=? ";
                prepStmt = con.prepareStatement(query);
                prepStmt.setString(1,x);
                rs=prepStmt.executeQuery();
                while(rs.next()){
                    // pname=rs.getString("pName");
                    
                    String m=rs.getString("solditems");
                    String n=rs.getString("currentStatus");
                    sold_items=Double.parseDouble(m)+z;
                    remaining_items=Double.parseDouble(n)-z;
                   
                    //System.out.println("sold:"+sold_items+" Remain:"+remaining_items);
                }   

            }catch(Exception e){
                System.out.println("Roor:"+e);
            }
      try{
          String crnt=Double.toString(remaining_items);
          String sld=Double.toString(sold_items);
          System.out.println("crnt:"+crnt+" sld:"+sld);
               String query="update vegetables set currentStatus = ?,solditems=? where  productName= ?";
            prepStmt = con.prepareStatement(query);
            prepStmt.setString(1,crnt);
            prepStmt.setString(2,sld);
            prepStmt.setString(3,x);
            prepStmt.executeUpdate();
               message.setText("ok veg");
           }catch(Exception e){
               message.setText("Error:"+e);
               System.out.println(""+e);
           }
  }else{
      if(y.equals("Beverage")){
          try{

                String query="select solditems,currentStatus  from beverage where productName=? ";
                prepStmt = con.prepareStatement(query);
                prepStmt.setString(1,x);
                rs=prepStmt.executeQuery();
                while(rs.next()){
                    // pname=rs.getString("pName");
                    
                    String m=rs.getString("solditems");
                    String n=rs.getString("currentStatus");
                    sold_items=Double.parseDouble(m)+z;
                    remaining_items=Double.parseDouble(n)-z;
                   
                    //System.out.println("sold:"+sold_items+" Remain:"+remaining_items);
                }   

            }catch(Exception e){
                System.out.println("Roor:"+e);
            }
      try{
          String crnt=Double.toString(remaining_items);
          String sld=Double.toString(sold_items);
          System.out.println("crnt:"+crnt+" sld:"+sld);
               String query="update beverage set currentStatus = ?,solditems=? where  productName= ?";
            prepStmt = con.prepareStatement(query);
            prepStmt.setString(1,crnt);
            prepStmt.setString(2,sld);
            prepStmt.setString(3,x);
            prepStmt.executeUpdate();
               message.setText("ok bev");
           }catch(Exception e){
               message.setText("Error:"+e);
               System.out.println(""+e);
           }
      }
  }
            }
  
  //UpdateDB(a);
}catch(Exception e){
    
}
    
     
    }
    //------------------------------------------------Total_cost---------------------------------------
    public void getData(){
        total_cost=0;
         for (int i = 0; i < tblProduct.getRowCount(); i++) {
  for (int j =4 ; j < tblProduct.getColumnCount(); j++) {
    Object o = tblProduct.getValueAt(i, j);
     if (o instanceof Double) {
        total_cost=total_cost+((Double)o);
    
    }
  }
} //System.out.println(total_cost);
  cost.setText("Cost:"+total_cost);
    }
    
    
    
    ////Add fuction after checking-----------------------------------------------------------------
    
    public void add_items(){
        if(checker>=5){
                model=(DefaultTableModel) tblProduct.getModel();

                if(!unit.getText().trim().equals("")){
                    if(!items.getText().trim().equals("")){
                        double v_s=Math.ceil(price_unit*items_number);
                        model.addRow(new Object[]{jTextField1.getSelectedItem(),jTextField1.getSelectedItem(),items_number,price_unit,v_s});
                    }else{
                        message.setText("You Must provide the  Items Number");
                    }

                }else{
                    message.setText("You Must provide the Price of the Item");
                }
            }else{
                message.setText("Shortage of items");
            }
    }
    
    
    //----------------------------------Update_Items--------------------------------------------------
    
   public void update_items(){
       if(checker>=5){
           
       
       if(tblProduct.getSelectedRow()==-1){
            if(tblProduct.getRowCount()==0){
                message.setText("Table is empty");
            }else{
                message.setText("You Must Select a product");
            }

        }else{
           double v_s=Math.ceil(price_unit*items_number);

            if(!unit.getText().trim().equals("")){
                if(!items.getText().trim().equals("")){
                    model.setValueAt(jTextField1.getSelectedItem(),tblProduct.getSelectedRow(), 0);
                    model.setValueAt(jTextField1.getSelectedItem(),tblProduct.getSelectedRow(), 1);
                    model.setValueAt(items_number,tblProduct.getSelectedRow(), 2);
                    model.setValueAt(price_unit,tblProduct.getSelectedRow(), 3);
                    model.setValueAt(v_s,tblProduct.getSelectedRow(), 4);
                }else{
                    message.setText("You Must provide the Item Numbers");
                }
                //  model.addRow(new Object[]{pName.getText(),cbCategory.getSelectedItem(),pPrice.getText()});

            }else{
                message.setText("You Must provide the Price of the Item");
            }

        }
       }else{
           message.setText("Sortage of products");
       }
   }
   
   ////-----------------------------------------------------------------
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jToolBar1 = new javax.swing.JToolBar();
        bCurrentDay = new javax.swing.JButton();
        bCurrentMonth = new javax.swing.JButton();
        bCurrentYear = new javax.swing.JButton();
        day2day = new javax.swing.JButton();
        month2month = new javax.swing.JButton();
        year2year = new javax.swing.JButton();
        addProducts = new javax.swing.JButton();
        updateItems = new javax.swing.JButton();
        bAdmin = new javax.swing.JButton();
        bClient = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        cbCategory = new javax.swing.JComboBox();
        pName = new javax.swing.JComboBox();
        items = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        unit = new javax.swing.JTextField();
        bAdd = new javax.swing.JButton();
        bUpdate = new javax.swing.JButton();
        bDelete = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblProduct = new javax.swing.JTable();
        message = new javax.swing.JLabel();
        pPrice = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        buy = new javax.swing.JButton();
        bClear = new javax.swing.JButton();
        cost = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        clientName = new javax.swing.JTextField();
        clientNumber = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        clientAddress = new javax.swing.JTextArea();
        jLabel10 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        icecreamStatus = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        iceCcreamTable = new javax.swing.JTable();
        iceMax = new javax.swing.JButton();
        iceMin = new javax.swing.JButton();
        iceClear = new javax.swing.JButton();
        iceMessage = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        fishTable = new javax.swing.JTable();
        bFish = new javax.swing.JButton();
        fishMax = new javax.swing.JButton();
        fishMin = new javax.swing.JButton();
        fishClear = new javax.swing.JButton();
        fishMessage = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        meatTable = new javax.swing.JTable();
        bMeat = new javax.swing.JButton();
        meatMax = new javax.swing.JButton();
        meatMin = new javax.swing.JButton();
        meatClear = new javax.swing.JButton();
        meatMessage = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        vegetableTable = new javax.swing.JTable();
        bVegetables = new javax.swing.JButton();
        vegMax = new javax.swing.JButton();
        vegMin = new javax.swing.JButton();
        vegClear = new javax.swing.JButton();
        vegMessage = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        bBeverage = new javax.swing.JButton();
        jScrollPane9 = new javax.swing.JScrollPane();
        beverageTable = new javax.swing.JTable();
        bevMax = new javax.swing.JButton();
        bevMin = new javax.swing.JButton();
        bevClear = new javax.swing.JButton();
        bevMessage = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 255, 0));

        jToolBar1.setRollover(true);

        bCurrentDay.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        bCurrentDay.setText("CurrentDay");
        bCurrentDay.setFocusable(false);
        bCurrentDay.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bCurrentDay.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bCurrentDay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCurrentDayActionPerformed(evt);
            }
        });
        jToolBar1.add(bCurrentDay);

        bCurrentMonth.setText("CurrentMonth");
        bCurrentMonth.setFocusable(false);
        bCurrentMonth.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bCurrentMonth.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bCurrentMonth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCurrentMonthActionPerformed(evt);
            }
        });
        jToolBar1.add(bCurrentMonth);

        bCurrentYear.setText("CurrentYear");
        bCurrentYear.setFocusable(false);
        bCurrentYear.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bCurrentYear.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bCurrentYear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCurrentYearActionPerformed(evt);
            }
        });
        jToolBar1.add(bCurrentYear);

        day2day.setText("DayToDay");
        day2day.setFocusable(false);
        day2day.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        day2day.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        day2day.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                day2dayActionPerformed(evt);
            }
        });
        jToolBar1.add(day2day);

        month2month.setText("MonthToMonth");
        month2month.setFocusable(false);
        month2month.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        month2month.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        month2month.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                month2monthActionPerformed(evt);
            }
        });
        jToolBar1.add(month2month);

        year2year.setText("YearToYear");
        year2year.setFocusable(false);
        year2year.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        year2year.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        year2year.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                year2yearActionPerformed(evt);
            }
        });
        jToolBar1.add(year2year);

        addProducts.setText("AddItems");
        addProducts.setFocusable(false);
        addProducts.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addProducts.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        addProducts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addProductsActionPerformed(evt);
            }
        });
        jToolBar1.add(addProducts);

        updateItems.setText("UpdateItems");
        updateItems.setFocusable(false);
        updateItems.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        updateItems.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        updateItems.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateItemsActionPerformed(evt);
            }
        });
        jToolBar1.add(updateItems);

        bAdmin.setText("AdmiN");
        bAdmin.setFocusable(false);
        bAdmin.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bAdmin.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAdminActionPerformed(evt);
            }
        });
        jToolBar1.add(bAdmin);

        bClient.setText("Client");
        bClient.setFocusable(false);
        bClient.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bClient.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bClient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bClientActionPerformed(evt);
            }
        });
        jToolBar1.add(bClient);

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

        jTabbedPane1.setBackground(new java.awt.Color(255, 204, 204));
        jTabbedPane1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTabbedPane1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(153, 204, 0));

        cbCategory.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cbCategory.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "IceCream", "Fish", "Meat", "Vegetables", "Beverage" }));
        cbCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbCategoryActionPerformed(evt);
            }
        });

        pName.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pNameActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setText("unit");

        bAdd.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        bAdd.setText("ADD");
        bAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAddActionPerformed(evt);
            }
        });

        bUpdate.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        bUpdate.setText("UPDATE");
        bUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bUpdateActionPerformed(evt);
            }
        });

        bDelete.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        bDelete.setText("DELETE");
        bDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bDeleteActionPerformed(evt);
            }
        });

        tblProduct.setBackground(new java.awt.Color(0, 0, 0));
        tblProduct.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        tblProduct.setForeground(new java.awt.Color(51, 204, 0));
        tblProduct.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ProductName", "Category", "Num Of Items", "Unit", "Cost"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblProduct.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblProductMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tblProduct);

        message.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        message.setForeground(new java.awt.Color(255, 0, 0));
        message.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel2.setText("Category:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel3.setText("Total Cost:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel4.setText("ProductName:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel5.setText("Number Of Items");

        buy.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        buy.setText("BUY");
        buy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buyActionPerformed(evt);
            }
        });

        bClear.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        bClear.setText("clear");
        bClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bClearActionPerformed(evt);
            }
        });

        cost.setBackground(new java.awt.Color(255, 255, 255));
        cost.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        cost.setForeground(new java.awt.Color(204, 0, 0));
        cost.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);

        jLabel6.setBackground(new java.awt.Color(0, 0, 204));
        jLabel6.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 0, 0));
        jLabel6.setText("Client Information");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel7.setText("Name");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel8.setText("PhoneNumber");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setText("Address");

        clientAddress.setColumns(20);
        clientAddress.setRows(5);
        jScrollPane3.setViewportView(clientAddress);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(204, 0, 0));
        jLabel10.setText("AUST CSE 2.1 SD LAB PROJECT BY DYNAMIC-32");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cost, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(bAdd, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(buy, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(items, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(unit, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(pName, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cbCategory, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(pPrice)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(bUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(bDelete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(bClear, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(38, 38, 38))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(27, 27, 27)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(clientNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(clientName, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 668, Short.MAX_VALUE)
                            .addComponent(message, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(302, 302, 302))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(message, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cbCategory)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 395, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addComponent(pName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(items, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)
                            .addComponent(unit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(pPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(bUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(bDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(bAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(1, 1, 1)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(buy)
                            .addComponent(bClear, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(clientName, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(clientNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(23, 23, 23)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cost, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE))
                .addContainerGap(348, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("BillingSystem", jPanel1);

        icecreamStatus.setText("Show Products");
        icecreamStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                icecreamStatusActionPerformed(evt);
            }
        });

        iceCcreamTable.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        iceCcreamTable.setForeground(new java.awt.Color(51, 153, 0));
        iceCcreamTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Product Name", "Status", "Total sold"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane5.setViewportView(iceCcreamTable);

        iceMax.setText("MAX");
        iceMax.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iceMaxActionPerformed(evt);
            }
        });

        iceMin.setText("MIN");
        iceMin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iceMinActionPerformed(evt);
            }
        });

        iceClear.setText("CLEAR");
        iceClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iceClearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(icecreamStatus, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                        .addComponent(iceMax, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(iceMin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(iceClear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(iceMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(46, 46, 46)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 673, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(497, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(icecreamStatus)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(iceMax)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(iceMin)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(iceClear)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(iceMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(414, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("IceCream", jPanel2);

        fishTable.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        fishTable.setForeground(new java.awt.Color(51, 153, 0));
        fishTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "productName", "currentStatus", "soldItems"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane6.setViewportView(fishTable);

        bFish.setText("Show Status");
        bFish.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bFishActionPerformed(evt);
            }
        });

        fishMax.setText("MAX");
        fishMax.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fishMaxActionPerformed(evt);
            }
        });

        fishMin.setText("MIN");
        fishMin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fishMinActionPerformed(evt);
            }
        });

        fishClear.setText("CLEAR");
        fishClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fishClearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(fishClear, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(fishMin, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(fishMax, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bFish, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE))
                    .addComponent(fishMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(83, 83, 83)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 595, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(530, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addComponent(bFish)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(fishMax)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(fishMin)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(fishClear)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(fishMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(378, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Fish", jPanel3);

        meatTable.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        meatTable.setForeground(new java.awt.Color(51, 204, 0));
        meatTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "productName", "CurrentStatus", "sold Items"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane7.setViewportView(meatTable);

        bMeat.setText("Show Status");
        bMeat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bMeatActionPerformed(evt);
            }
        });

        meatMax.setText("MAX");
        meatMax.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                meatMaxActionPerformed(evt);
            }
        });

        meatMin.setText("MIN");
        meatMin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                meatMinActionPerformed(evt);
            }
        });

        meatClear.setText("CLEAR");
        meatClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                meatClearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(bMeat, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                    .addComponent(meatMax, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(meatMin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(meatClear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(meatMessage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(104, 104, 104)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 571, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(562, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(bMeat)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(meatMax)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(meatMin)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(meatClear)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(meatMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(477, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Meat", jPanel4);

        vegetableTable.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        vegetableTable.setForeground(new java.awt.Color(51, 204, 0));
        vegetableTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "productName", "currentAmount", "Sold Items"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane8.setViewportView(vegetableTable);

        bVegetables.setText("Show Status");
        bVegetables.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVegetablesActionPerformed(evt);
            }
        });

        vegMax.setText("MAX");
        vegMax.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vegMaxActionPerformed(evt);
            }
        });

        vegMin.setText("MIN");
        vegMin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vegMinActionPerformed(evt);
            }
        });

        vegClear.setText("CLEAR");
        vegClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vegClearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(bVegetables, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE)
                    .addComponent(vegMax, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(vegMin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(vegClear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(vegMessage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(56, 56, 56)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 637, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(540, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(bVegetables)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(vegMax)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(vegMin)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(vegClear)
                        .addGap(18, 18, 18)
                        .addComponent(vegMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(480, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Vegetables", jPanel5);

        bBeverage.setText("Show Status");
        bBeverage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBeverageActionPerformed(evt);
            }
        });

        beverageTable.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        beverageTable.setForeground(new java.awt.Color(51, 204, 0));
        beverageTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "productName", "currentAmount", "Sold Items"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane9.setViewportView(beverageTable);

        bevMax.setText("MAX");
        bevMax.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bevMaxActionPerformed(evt);
            }
        });

        bevMin.setText("MIN");
        bevMin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bevMinActionPerformed(evt);
            }
        });

        bevClear.setText("CLEAR");
        bevClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bevClearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(bBeverage, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                    .addComponent(bevMax, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bevMin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bevClear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bevMessage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(89, 89, 89)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 584, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(572, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(bBeverage)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(bevMax)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bevMin)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(bevClear)
                        .addGap(18, 18, 18)
                        .addComponent(bevMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(499, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Beverage", jPanel6);

        jScrollPane1.setViewportView(jTabbedPane1);

        jScrollPane2.setViewportView(jScrollPane1);

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        jMenu3.setText("Amdin");
        jMenuBar1.add(jMenu3);

        jMenu4.setText("Shortcut");
        jMenuBar1.add(jMenu4);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jToolBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1184, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 562, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bCurrentDayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCurrentDayActionPerformed
      DB ob = new DB();
      ob.getDay();       
    }//GEN-LAST:event_bCurrentDayActionPerformed

    private void bCurrentMonthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCurrentMonthActionPerformed
       DB ob = new DB();
      ob.getMonth(); 
       
    }//GEN-LAST:event_bCurrentMonthActionPerformed

    private void bCurrentYearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCurrentYearActionPerformed
       DB ob = new DB();
      ob.getYear(); 
       
    }//GEN-LAST:event_bCurrentYearActionPerformed

    private void day2dayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_day2dayActionPerformed
        DayToDay frm = new DayToDay();
        frm.setVisible(true);
    }//GEN-LAST:event_day2dayActionPerformed

    private void year2yearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_year2yearActionPerformed
        MonthToMonth1 frm = new MonthToMonth1();
        frm.setVisible(true);
    }//GEN-LAST:event_year2yearActionPerformed

    private void month2monthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_month2monthActionPerformed
           MonthToMonth frm = new MonthToMonth();
        frm.setVisible(true);
    }//GEN-LAST:event_month2monthActionPerformed

    private void bBeverageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBeverageActionPerformed
        DefaultTableModel model=(DefaultTableModel) beverageTable.getModel();
        model.setRowCount(0);
        try{
            //   Daysearch day =new Daysearch();
            String query="select *  from beverage";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName");
                String d=rs.getString("id");
                String yr=rs.getString("productName");
                String m=rs.getString("currentStatus");
                String t=rs.getString("solditems");
                model.addRow(new Object[]{d,yr,m,t});
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }//GEN-LAST:event_bBeverageActionPerformed

    private void bVegetablesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVegetablesActionPerformed
        DefaultTableModel model=(DefaultTableModel) vegetableTable.getModel();
        model.setRowCount(0);
        try{
            //   Daysearch day =new Daysearch();
            String query="select *  from vegetables";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName");
                String d=rs.getString("id");
                String yr=rs.getString("productName");
                String m=rs.getString("currentStatus");
                String t=rs.getString("solditems");
                model.addRow(new Object[]{d,yr,m,t});
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }//GEN-LAST:event_bVegetablesActionPerformed

    private void bMeatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bMeatActionPerformed
        DefaultTableModel model=(DefaultTableModel) meatTable.getModel();
        model.setRowCount(0);
        try{
            //   Daysearch day =new Daysearch();
            String query="select *  from meat";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName");
                String d=rs.getString("id");
                String yr=rs.getString("productName");
                String m=rs.getString("currentStatus");
                String t=rs.getString("solditems");
                model.addRow(new Object[]{d,yr,m,t});
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }//GEN-LAST:event_bMeatActionPerformed

    private void bFishActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bFishActionPerformed
        DefaultTableModel model=(DefaultTableModel) fishTable.getModel();
        model.setRowCount(0);
        try{
            //   Daysearch day =new Daysearch();
            String query="select *  from fish";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName");
                String d=rs.getString("id");
                String yr=rs.getString("productName");
                String m=rs.getString("currentStatus");
                String t=rs.getString("solditems");
                model.addRow(new Object[]{d,yr,m,t});
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }//GEN-LAST:event_bFishActionPerformed

    private void icecreamStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_icecreamStatusActionPerformed
        DefaultTableModel model=(DefaultTableModel) iceCcreamTable.getModel();
        model.setRowCount(0);
        try{
            //   Daysearch day =new Daysearch();
            String query="select *  from icecream";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName");
                String d=rs.getString("id");
                String yr=rs.getString("productName");
                String m=rs.getString("crrentStatus");
                String t=rs.getString("sold");
                model.addRow(new Object[]{d,yr,m,t});
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }//GEN-LAST:event_icecreamStatusActionPerformed

    private void buyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buyActionPerformed
      int nd=0;
        client_name=clientName.getText();
        String phn=clientNumber.getText();
        String add=clientAddress.getText();
         String tt_cost=Double.toString(total_cost);
      if(client_name.length()>=3 && phn.length()>5 && add.length()>3){
      //  System.out.println(""+client_name);
        try{
          String query="select * from client ";
                prepStmt = con.prepareStatement(query);
                rs=prepStmt.executeQuery();
                while(rs.next()){                   
                    String n=rs.getString("cName"); 
                   // System.out.println("N:"+n);
                    if(n.equals(client_name) ){
                       JOptionPane.showMessageDialog(null, "Soryy..This Name Already ExistS");   
                        nd++;
                    }
                }
                if(nd==0){
                    String confirm=JOptionPane.showInputDialog(null,"Pess y to Confirm");
                    if(confirm.equals("y")){
                      try{
       String query2="INSERT INTO client(cName,phone,address,cCost) VALUES(?,?,?,?)";
                prepStmt = con.prepareStatement(query2);
                prepStmt.setString(1,client_name);
                prepStmt.setString(2,phn);
                prepStmt.setString(3,add);
                prepStmt.setString(4,tt_cost);
                prepStmt.executeUpdate();
                ss();
                inserInToAdmin();
                passValue();
                          System.out.println("okay");
  }catch(Exception e){
      System.out.println("e:"+e);
  }  
                    }else{
                        JOptionPane.showMessageDialog(null, "You must press y to buy ");
                    }
                      
                }
      }catch(Exception e){
          JOptionPane.showMessageDialog(null, "bla bla bla!!!"+e);
      }
    }   
      else{
         // System.out.println(" ");
           JOptionPane.showMessageDialog(null, "Client name must be greater then or equal to 3 Or U didt fill full form");
      }
      
     //   ss();
     //   inserInToAdmin();
    }//GEN-LAST:event_buyActionPerformed

    private void tblProductMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblProductMouseClicked
        // TODO add your handling code here:
        message.setText("");
        DefaultTableModel model=(DefaultTableModel) tblProduct.getModel();
        try{
            jTextField1.setSelectedItem(model.getValueAt(tblProduct.getSelectedRow(),1).toString());
            jTextField1.setSelectedItem(model.getValueAt(tblProduct.getSelectedRow(),0).toString());
            items.setText(model.getValueAt(tblProduct.getSelectedRow(),2).toString());
            unit.setText(model.getValueAt(tblProduct.getSelectedRow(),3).toString());
            pPrice.setText(model.getValueAt(tblProduct.getSelectedRow(),4).toString());
        }catch(Exception e){
            message.setText(e.toString());
        }
         getRowId=tblProduct.getSelectedRow();
        System.out.println(""+getRowId);
    }//GEN-LAST:event_tblProductMouseClicked

    private void bDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bDeleteActionPerformed
        // TODO add your handling code here:
        message.setText("");
        DefaultTableModel model=(DefaultTableModel) tblProduct.getModel();
        if(tblProduct.getSelectedRow()==-1){
            if(tblProduct.getRowCount()==0){
                message.setText("Table is empty");
            }else{
                message.setText("You Must Select a product");
            }

        }else{
            model.removeRow(tblProduct.getSelectedRow());
        }
        getData();
    }//GEN-LAST:event_bDeleteActionPerformed

    private void bUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bUpdateActionPerformed
        // TODO add your handling code here:
      
        message.setText("");
        int match_checker=0;
         String p="";      
          items_number=0;
         price_unit=0;
        String cat=(String)jTextField1.getSelectedItem();
        String p_name=(String) jTextField1.getSelectedItem();
      //int rowIndex=0;
      //int colIndex=0;
        

        try{
            items_number=Double.parseDouble(items.getText());

        }catch(Exception e){
            message.setText("inpuzt integer");
        }
        try{
            price_unit=Double.parseDouble(unit.getText());
        }catch(Exception e){
            message.setText("input integer");
        } 
      
        //--------------------------------------------------------------------------
    //  System.out.println("row"+rowIndex+"col:"+colIndex);
        for (int i = 0; i < tblProduct.getRowCount(); i++) {
          for (int j = 0; j < 1; j++) {
              if(i != getRowId){
            Object o = tblProduct.getValueAt(i, j);
             if (o instanceof String) {
                 p=((String)o);
                   if(p_name.equals(p)){            
                      match_checker++;
                    }
          }
         } 
             
  }
}
        
///--------------------------------------------------------------------------------------------------------- 
        if(match_checker==0){
        if(cat.equals("IceCream")){
        try{
            try{

                String query="select crrentStatus  from icecream where productName=? ";
                prepStmt = con.prepareStatement(query);
                prepStmt.setString(1,p_name);
                rs=prepStmt.executeQuery();
                while(rs.next()){
                    // pname=rs.getString("pName");
                    String m=rs.getString("crrentStatus");
              ///\     System.out.println(p_name+":"+m);
                    checker=Integer.parseInt(m);
                }
                checker=checker-items_number;

            }catch(Exception e){
                System.out.println("Roor:"+e);
            }
            
            update_items();
        }
        catch(Exception e){
            message.setText(e.toString());
        }
        }else if(cat.equals("Fish")){
          try{
            try{
                String query="select currentStatus  from fish where productName=? ";
                prepStmt = con.prepareStatement(query);
                prepStmt.setString(1,p_name);
                rs=prepStmt.executeQuery();
                while(rs.next()){
                    // pname=rs.getString("pName");
                    String m=rs.getString("currentStatus");
                   //System.out.println(p_name+":"+m);
                    checker=Integer.parseInt(m);
                }
                checker=checker-items_number;

            }catch(Exception e){
                System.out.println("Roor:"+e);
            }
            ////////////adding intems  
            update_items();
            ///End of adding items
        }
        catch(Exception e){
            message.setText(e.toString());
        }  
       }else if(cat.equals("Meat")){
          try{
            try{
                String query="select currentStatus  from meat where productName=? ";
                prepStmt = con.prepareStatement(query);
                prepStmt.setString(1,p_name);
                rs=prepStmt.executeQuery();
                while(rs.next()){
                    // pname=rs.getString("pName");
                    String m=rs.getString("currentStatus");
                   System.out.println(p_name+":"+m);
                    checker=Integer.parseInt(m);
                }
                checker=checker-items_number;

            }catch(Exception e){
                System.out.println("Roor:"+e);
            }
            ////////////adding intems  
            update_items();
            ///End of adding items
        }
        catch(Exception e){
            message.setText(e.toString());
        }  
       }else if(cat.equals("Vegetables")){
          try{
            try{
                String query="select currentStatus  from vegetables where productName=? ";
                prepStmt = con.prepareStatement(query);
                prepStmt.setString(1,p_name);
                rs=prepStmt.executeQuery();
                while(rs.next()){
                    // pname=rs.getString("pName");
                    String m=rs.getString("currentStatus");
                   System.out.println(p_name+":"+m);
                    checker=Integer.parseInt(m);
                }
                checker=checker-items_number;

            }catch(Exception e){
                System.out.println("Roor:"+e);
            }
            ////////////adding intems  
            update_items();
            ///End of adding items
        }
        catch(Exception e){
            message.setText(e.toString());
        }  
       }else if(cat.equals("Beverage")){
          try{
            try{
                String query="select currentStatus  from beverage where productName=? ";
                prepStmt = con.prepareStatement(query);
                prepStmt.setString(1,p_name);
                rs=prepStmt.executeQuery();
                while(rs.next()){
                    // pname=rs.getString("pName");
                    String m=rs.getString("currentStatus");
                   System.out.println(p_name+":"+m);
                    checker=Integer.parseInt(m);
                }
                checker=checker-items_number;

            }catch(Exception e){
                System.out.println("Roor:"+e);
            }
            ////////////adding intems  
            update_items();
            ///End of adding items
        }
        catch(Exception e){
            message.setText(e.toString());
        }  
       }
      }else{
            message.setText("probally done");
        }
        getData();

    }//GEN-LAST:event_bUpdateActionPerformed

    private void bAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAddActionPerformed
        // TODO add your handling code here:
        int match_checker=0;
        message.setText("");
         String p="";
         items_number=0;
         price_unit =0;
        String cat=(String)jTextField1.getText();
        String p_name=(String) jTextField1.getSelectedItem();
     //   System.out.println("cat:"+cat +" pname:"+p_name);
       
        for (int i = 0; i < tblProduct.getRowCount(); i++) {
  for (int j = 0; j < 1; j++) {
    Object o = tblProduct.getValueAt(i, j);
    if (o instanceof String) {
         p=((String)o);
        if(p_name.equals(p)){            
             match_checker++;
         }
         
     // System.out.println("hi:"+p);
    }else if (o instanceof Integer) {
     // System.out.println((Integer)o);
    }else if (o instanceof Double) {
     // System.out.println((Double)o);
    }else if (o instanceof Double) {
     // System.out.println((Double)o);
    }
  }
}
        // System.out.println("read:"+p);
         
    if(match_checker==0){
        
    
        try{
            items_number=Double.parseDouble(items.getText());

        }catch(Exception e){
            message.setText("input integer");
        }
        try{
            price_unit=Double.parseDouble(unit.getText());
        }catch(Exception e){
            message.setText("input integer");
        }
        

        //message.setText("");
        
        if(cat.equals("IceCream")){
        try{
            try{

                String query="select crrentStatus  from icecream where productName=? ";
                prepStmt = con.prepareStatement(query);
                prepStmt.setString(1,p_name);
                rs=prepStmt.executeQuery();
                while(rs.next()){
                    // pname=rs.getString("pName");
                    String m=rs.getString("crrentStatus");
                  System.out.println(":"+m);
                    checker=Integer.parseInt(m);
                }
                checker=checker-items_number;

            }catch(Exception e){
                System.out.println("Roor:"+e);
            }
            ////////////adding intems  
            add_items();
            ///End of adding items
        }
        catch(Exception e){
            message.setText(e.toString());
        }
        }else if(cat.equals("Fish")){
          try{
            try{
                String query="select currentStatus  from fish where productName=? ";
                prepStmt = con.prepareStatement(query);
                prepStmt.setString(1,p_name);
                rs=prepStmt.executeQuery();
                while(rs.next()){
                    // pname=rs.getString("pName");
                    String m=rs.getString("currentStatus");
                   //System.out.println(p_name+":"+m);
                    checker=Integer.parseInt(m);
                }
                checker=checker-items_number;

            }catch(Exception e){
                System.out.println("Roor:"+e);
            }
            ////////////adding intems  
            add_items();
            ///End of adding items
        }
        catch(Exception e){
            message.setText(e.toString());
        }  
       }else if(cat.equals("Beverage")){
          try{
            try{
                String query="select currentStatus  from beverage where productName=? ";
                prepStmt = con.prepareStatement(query);
                prepStmt.setString(1,p_name);
                rs=prepStmt.executeQuery();
                while(rs.next()){
                    // pname=rs.getString("pName");
                    String m=rs.getString("currentStatus");
                   System.out.println(p_name+":"+m);
                    checker=Integer.parseInt(m);
                }
                checker=checker-items_number;

            }catch(Exception e){
                System.out.println("Roor:"+e);
            }
            ////////////adding intems  
            add_items();
            ///End of adding items
        }
        catch(Exception e){
            message.setText(e.toString());
        }  
       } else if(cat.equals("Meat")){
          try{
            try{
                String query="select currentStatus  from meat where productName=? ";
                prepStmt = con.prepareStatement(query);
                prepStmt.setString(1,p_name);
                rs=prepStmt.executeQuery();
                while(rs.next()){
                    // pname=rs.getString("pName");
                    String m=rs.getString("currentStatus");
                   System.out.println(p_name+":"+m);
                    checker=Integer.parseInt(m);
                }
                checker=checker-items_number;

            }catch(Exception e){
                System.out.println("Roor:"+e);
            }
            ////////////adding intems  
            add_items();
            ///End of adding items
        }
        catch(Exception e){
            message.setText(e.toString());
        }  
       } else if(cat.equals("Vegetables")){
          try{
            try{
                String query="select currentStatus  from vegetables where productName=? ";
                prepStmt = con.prepareStatement(query);
                prepStmt.setString(1,p_name);
                rs=prepStmt.executeQuery();
                while(rs.next()){
                    // pname=rs.getString("pName");
                    String m=rs.getString("currentStatus");
                   System.out.println(p_name+":"+m);
                    checker=Integer.parseInt(m);
                }
                checker=checker-items_number;

            }catch(Exception e){
                System.out.println("Roor:"+e);
            }
            ////////////adding intems  
            add_items();
            ///End of adding items
        }
        catch(Exception e){
            message.setText(e.toString());
        }  
       }     
    }else{
         message.setText("Match!!!you can't add one product twice!!please update");
    }
        getData();
    }//GEN-LAST:event_bAddActionPerformed

    private void bClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bClearActionPerformed
        cost.setText("");
        message.setText("");
        clientName.setText("");
        clientNumber.setText("");
        clientAddress.setText("");
        items.setText("");
        unit.setText("");
        pPrice.setText("");
        model.setRowCount(0);
    }//GEN-LAST:event_bClearActionPerformed

    private void iceMaxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iceMaxActionPerformed
        iceMessage.setText("");
        model=(DefaultTableModel) iceCcreamTable.getModel();
        
        try{
            //   Daysearch day =new Daysearch();
            String query="select MAX(sold)  from icecream";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName");
                String d=rs.getString("MAX(sold)");
                iceMessage.setText(""+d);
                
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }//GEN-LAST:event_iceMaxActionPerformed

    private void iceMinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iceMinActionPerformed
        // TODO add your handling code here:
          iceMessage.setText("");
        model=(DefaultTableModel) iceCcreamTable.getModel();
        
        try{
            //   Daysearch day =new Daysearch();
            String query="select MIN(sold)  from icecream";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName");
                String d=rs.getString("MIN(sold)");
                iceMessage.setText(""+d);
                
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }//GEN-LAST:event_iceMinActionPerformed

    private void iceClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iceClearActionPerformed
        // TODO add your handling code here:
        iceMessage.setText("");
        model=(DefaultTableModel) iceCcreamTable.getModel();
        model.setRowCount(0);
    }//GEN-LAST:event_iceClearActionPerformed

    private void fishMaxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fishMaxActionPerformed
        // TODO add your handling code here:
          fishMessage.setText("");
        model=(DefaultTableModel) fishTable.getModel();
        
        try{
            //   Daysearch day =new Daysearch();
            String query="select MAX(solditems)  from fish";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName");
                String d=rs.getString("MAX(solditems)");
                fishMessage.setText(""+d);
                
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }//GEN-LAST:event_fishMaxActionPerformed

    private void fishMinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fishMinActionPerformed
        // TODO add your handling code here:
          fishMessage.setText("");
        model=(DefaultTableModel) fishTable.getModel();
        
        try{
            //   Daysearch day =new Daysearch();
            String query="select MIN(solditems)  from fish";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName");
                String d=rs.getString("MIN(solditems)");
                fishMessage.setText(""+d);
                
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }//GEN-LAST:event_fishMinActionPerformed

    private void fishClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fishClearActionPerformed
        // TODO add your handling code here:
        fishMessage.setText("");
        model=(DefaultTableModel) fishTable.getModel();
        model.setRowCount(0);
    }//GEN-LAST:event_fishClearActionPerformed

    private void meatMaxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_meatMaxActionPerformed
        // TODO add your handling code here:
        model=(DefaultTableModel) meatTable.getModel();
        
        try{
            //   Daysearch day =new Daysearch();
            String query="select MAX(solditems)  from meat";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName");
                String d=rs.getString("MAX(solditems)");
                meatMessage.setText(""+d);
                
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }//GEN-LAST:event_meatMaxActionPerformed

    private void meatMinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_meatMinActionPerformed
        // TODO add your handling code here:
        model=(DefaultTableModel) meatTable.getModel();
        
        try{
            //   Daysearch day =new Daysearch();
            String query="select MIN(solditems)  from meat";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName");
                String d=rs.getString("MIN(solditems)");
                meatMessage.setText(""+d);
                
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }//GEN-LAST:event_meatMinActionPerformed

    private void meatClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_meatClearActionPerformed
        // TODO add your handling code here:
         meatMessage.setText("");
        model=(DefaultTableModel) meatTable.getModel();
        model.setRowCount(0);
    }//GEN-LAST:event_meatClearActionPerformed

    private void vegMaxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vegMaxActionPerformed
        // TODO add your handling code here:
         vegMessage.setText("");
        model=(DefaultTableModel) vegetableTable.getModel();
        
        try{
            //   Daysearch day =new Daysearch();
            String query="select MAX(solditems)  from vegetables";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName");
                String d=rs.getString("MAX(solditems)");
                vegMessage.setText(""+d);
                
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }//GEN-LAST:event_vegMaxActionPerformed

    private void vegMinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vegMinActionPerformed
        // TODO add your handling code here:
         vegMessage.setText("");
        model=(DefaultTableModel) vegetableTable.getModel();
        
        try{
            //   Daysearch day =new Daysearch();
            String query="select MIN(solditems)  from vegetables";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName");
                String d=rs.getString("MIN(solditems)");
                vegMessage.setText(""+d);
                
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }//GEN-LAST:event_vegMinActionPerformed

    private void vegClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vegClearActionPerformed
        // TODO add your handling code here:
        vegMessage.setText("");
        model=(DefaultTableModel) vegetableTable.getModel();
        model.setRowCount(0);
    }//GEN-LAST:event_vegClearActionPerformed

    private void bevMaxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bevMaxActionPerformed
        // TODO add your handling code here:
        bevMessage.setText("");
        model=(DefaultTableModel) beverageTable.getModel();
        
        try{
            //   Daysearch day =new Daysearch();
            String query="select MAX(solditems)  from beverage";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName");
                String d=rs.getString("MAX(solditems)");
                bevMessage.setText(""+d);
                
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }//GEN-LAST:event_bevMaxActionPerformed

    private void bevMinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bevMinActionPerformed
        // TODO add your handling code here:
         bevMessage.setText("");
        model=(DefaultTableModel) beverageTable.getModel();
        
        try{
            //   Daysearch day =new Daysearch();
            String query="select MIN(solditems)  from beverage";
            prepStmt = con.prepareStatement(query);
            rs=prepStmt.executeQuery();
            while(rs.next()){
                // pname=rs.getString("pName");
                String d=rs.getString("MIN(solditems)");
                bevMessage.setText(""+d);
                
            }
            //     message.setText("Total Cost: "+total+" Taka");
            // message.setText(""+sDay+" "+eDay);
        }catch(Exception e){
            System.out.println("Roor:"+e);
        }
    }//GEN-LAST:event_bevMinActionPerformed

    private void bevClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bevClearActionPerformed
        // TODO add your handling code here:
        bevMessage.setText("");
        model=(DefaultTableModel) beverageTable.getModel();
        model.setRowCount(0);
    }//GEN-LAST:event_bevClearActionPerformed

    private void updateItemsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateItemsActionPerformed
        // TODO add your handling code here:
         
        String adminSecurity="";
      // adminSecurity=JOptionPane.showInputDialog(null,"Admin Security Question");
        JPasswordField pf = new JPasswordField();
int okCxl = JOptionPane.showConfirmDialog(null, pf, "Enter Password", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

if (okCxl == JOptionPane.OK_OPTION) {
  adminSecurity = new String(pf.getPassword());
 // System.err.println("You entered: " + password);
}
       try{
               String query="select password,admin from login ";
                prepStmt = con.prepareStatement(query);
                rs=prepStmt.executeQuery();
                while(rs.next()){ 
                   
                    String o=rs.getString("admin");
                    if(adminSecurity.equals(o)){
        updateProducts frm = new updateProducts ();
        frm.setVisible(true);
       }else{
           JOptionPane.showMessageDialog(null,"This service is only for Admin");
       }
                   
                }                 

       }catch(Exception e){
       JOptionPane.showMessageDialog(null,"Have a nice day");
       }
    }//GEN-LAST:event_updateItemsActionPerformed

    private void addProductsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addProductsActionPerformed
       String adminSecurity="";
     //  adminSecurity=JOptionPane.showInputDialog(null,"Admin Security Question");
       JPasswordField pf = new JPasswordField();
int okCxl = JOptionPane.showConfirmDialog(null, pf, "Enter Password", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

if (okCxl == JOptionPane.OK_OPTION) {
  adminSecurity = new String(pf.getPassword());
  //System.err.println("You entered: " + password);
}
       try{
               String query="select password,admin from login ";
                prepStmt = con.prepareStatement(query);
                rs=prepStmt.executeQuery();
                while(rs.next()){ 
                   
                    String o=rs.getString("admin");
                    if(adminSecurity.equals(o)){
        addProducts frm = new addProducts ();
        frm.setVisible(true);
       }else{
           JOptionPane.showMessageDialog(null,"This service is only for Admin");
       }
                   
                }                 

       }catch(Exception e){
       JOptionPane.showMessageDialog(null,"Have a nice day");
       }
       
    }//GEN-LAST:event_addProductsActionPerformed

    private void bClientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bClientActionPerformed
         
        Client frm = new Client();
        frm.setVisible(true);
       
    }//GEN-LAST:event_bClientActionPerformed

    private void bAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAdminActionPerformed
         String adminSecurity="";
    //   adminSecurity=JOptionPane.showInputDialog(null,"Admin Security Question");
             JPasswordField pf = new JPasswordField();
int okCxl = JOptionPane.showConfirmDialog(null, pf, "Enter Password", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

if (okCxl == JOptionPane.OK_OPTION) {
  adminSecurity = new String(pf.getPassword());
  //System.err.println("You entered: " + password);
}
       try{
               String query="select password,admin from login ";
                prepStmt = con.prepareStatement(query);
                rs=prepStmt.executeQuery();
                while(rs.next()){ 
                   
                    String o=rs.getString("admin");
                    if(adminSecurity.equals(o)){
        Amdin frm = new Amdin ();
        frm.setVisible(true);
       }else{
           JOptionPane.showMessageDialog(null,"This service is only for Admin");
       }
                   
                }                 

       }catch(Exception e){
       JOptionPane.showMessageDialog(null,"Have a nice day");
       }
    }//GEN-LAST:event_bAdminActionPerformed

    private void pNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pNameActionPerformed

    private void cbCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbCategoryActionPerformed
        // TODO add your handling code here:
        try{  name=(String)cbCategory.getSelectedItem();
            if(name=="IceCream"){
                pName.removeAllItems();
                try{
                    //   Daysearch day =new Daysearch();
                    String query="select *  from icecream";
                    prepStmt = con.prepareStatement(query);
                    rs=prepStmt.executeQuery();
                    while(rs.next()){
                        // pname=rs.getString("pName")
                        String yr=rs.getString("productName");

                        pName.addItem(yr);
                    }
                    //     message.setText("Total Cost: "+total+" Taka");
                    // message.setText(""+sDay+" "+eDay);
                }catch(Exception e){
                    System.out.println("Roor:"+e);
                }
                //  pName.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "mango", "bellicimo", "straberry", "vennila" }));
            }else if(name=="Fish"){
                pName.removeAllItems();
                try{
                    //   Daysearch day =new Daysearch();
                    String query="select *  from fish";
                    prepStmt = con.prepareStatement(query);
                    rs=prepStmt.executeQuery();
                    while(rs.next()){
                        // pname=rs.getString("pName")
                        String yr=rs.getString("productName");

                        pName.addItem(yr);
                    }
                    //     message.setText("Total Cost: "+total+" Taka");
                    // message.setText(""+sDay+" "+eDay);
                }catch(Exception e){
                    System.out.println("Roor:"+e);
                }
                // pName.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "rui", "chatla", "ilsha", "koi" }));
            }else if(name=="Meat"){
                pName.removeAllItems();
                try{
                    //   Daysearch day =new Daysearch();
                    String query="select *  from meat";
                    prepStmt = con.prepareStatement(query);
                    rs=prepStmt.executeQuery();
                    while(rs.next()){
                        // pname=rs.getString("pName")
                        String yr=rs.getString("productName");

                        pName.addItem(yr);
                    }
                    //     message.setText("Total Cost: "+total+" Taka");
                    // message.setText(""+sDay+" "+eDay);
                }catch(Exception e){
                    System.out.println("Roor:"+e);
                }
                // pName.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "beef", "mutton", "chicken", "duck" }));
            }else if(name=="Vegetables"){
                pName.removeAllItems();
                try{
                    //   Daysearch day =new Daysearch();
                    String query="select *  from vegetables";
                    prepStmt = con.prepareStatement(query);
                    rs=prepStmt.executeQuery();
                    while(rs.next()){
                        // pname=rs.getString("pName")
                        String yr=rs.getString("productName");

                        pName.addItem(yr);
                    }
                    //     message.setText("Total Cost: "+total+" Taka");
                    // message.setText(""+sDay+" "+eDay);
                }catch(Exception e){
                    System.out.println("Roor:"+e);
                }
                // pName.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "potato", "onion", "chilli", "tomato","lemon" }));
            }else{
                if( name=="Beverage"){
                    pName.removeAllItems();
                    try{
                        //   Daysearch day =new Daysearch();
                        String query="select *  from beverage";
                        prepStmt = con.prepareStatement(query);
                        rs=prepStmt.executeQuery();
                        while(rs.next()){
                            // pname=rs.getString("pName")
                            String yr=rs.getString("productName");

                            pName.addItem(yr);
                        }
                        //     message.setText("Total Cost: "+total+" Taka");
                        // message.setText(""+sDay+" "+eDay);
                    }catch(Exception e){
                        System.out.println("Roor:"+e);
                    }
                }
                //  pName.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "cocacola", "pepsi", "fanta", "dew" }));
            }
        }catch(Exception e){
            message.setText(""+e);
        }
    }//GEN-LAST:event_cbCategoryActionPerformed
                                              

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            //    new NewJFrame().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addProducts;
    private javax.swing.JButton bAdd;
    private javax.swing.JButton bAdmin;
    private javax.swing.JButton bBeverage;
    private javax.swing.JButton bClear;
    private javax.swing.JButton bClient;
    private javax.swing.JButton bCurrentDay;
    private javax.swing.JButton bCurrentMonth;
    private javax.swing.JButton bCurrentYear;
    private javax.swing.JButton bDelete;
    private javax.swing.JButton bFish;
    private javax.swing.JButton bMeat;
    private javax.swing.JButton bUpdate;
    private javax.swing.JButton bVegetables;
    private javax.swing.JButton bevClear;
    private javax.swing.JButton bevMax;
    private javax.swing.JLabel bevMessage;
    private javax.swing.JButton bevMin;
    private javax.swing.JTable beverageTable;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton buy;
    private javax.swing.JComboBox cbCategory;
    private javax.swing.JTextArea clientAddress;
    private javax.swing.JTextField clientName;
    private javax.swing.JTextField clientNumber;
    private javax.swing.JLabel cost;
    private javax.swing.JButton day2day;
    private javax.swing.JButton fishClear;
    private javax.swing.JButton fishMax;
    private javax.swing.JLabel fishMessage;
    private javax.swing.JButton fishMin;
    private javax.swing.JTable fishTable;
    private javax.swing.JTable iceCcreamTable;
    private javax.swing.JButton iceClear;
    private javax.swing.JButton iceMax;
    private javax.swing.JLabel iceMessage;
    private javax.swing.JButton iceMin;
    private javax.swing.JButton icecreamStatus;
    private javax.swing.JTextField items;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JButton meatClear;
    private javax.swing.JButton meatMax;
    private javax.swing.JLabel meatMessage;
    private javax.swing.JButton meatMin;
    private javax.swing.JTable meatTable;
    private javax.swing.JLabel message;
    private javax.swing.JButton month2month;
    private javax.swing.JComboBox pName;
    private javax.swing.JTextField pPrice;
    private javax.swing.JTable tblProduct;
    private javax.swing.JTextField unit;
    private javax.swing.JButton updateItems;
    private javax.swing.JButton vegClear;
    private javax.swing.JButton vegMax;
    private javax.swing.JLabel vegMessage;
    private javax.swing.JButton vegMin;
    private javax.swing.JTable vegetableTable;
    private javax.swing.JButton year2year;
    // End of variables declaration//GEN-END:variables
}
