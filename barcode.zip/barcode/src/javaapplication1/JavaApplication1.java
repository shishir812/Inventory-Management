package javaapplication1;
public class JavaApplication1 {
    public static void main(String[] args) {
        // TODO code application logic here
        //System.out.println("rumi");
           // new NewJFrame().setVisible(true);
         //new LoginPage().setVisible(true);
            new Login().setVisible(true);
    }
}
