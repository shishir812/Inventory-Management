package javaapplication1;
import java.sql.*;
import java.util.Calendar;
import javax.swing.table.DefaultTableModel;

public class DB {
    java.util.Date now = new java.util.Date();
    Calendar cal = Calendar.getInstance();
    double total=0;
     private  Connection con;
  private Statement st;
  private ResultSet rs;
  PreparedStatement prepStmt = null;
  
  int YEAR = Calendar.getInstance().get(Calendar.YEAR);
  int MONTH = Calendar.getInstance().get(Calendar.MONTH)+1;
  int DAY_OF_MONTH = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
  
  String strYear=Integer.toString(YEAR);
  String strMonth=Integer.toString(MONTH);
  String strDay=Integer.toString(DAY_OF_MONTH );
  
  public DB(){
      try{
          Class.forName("com.mysql.jdbc.Driver");
          con=DriverManager.getConnection("jdbc:mysql://localhost/shopmanagemant","root","");
          st=con.createStatement(); 
         
      }catch(Exception ex){
          System.out.println("Error:"+ex);
      }
  }
  public void getDay(){
      try{
          Daysearch day =new Daysearch();
          day.setVisible(true);
               String query="select day,month,year,time,cost from admintable where day=? and month=? and year=?";
         prepStmt = con.prepareStatement(query);
         prepStmt.setString(1,strDay);
         prepStmt.setString(2,strMonth);
         prepStmt.setString(3,strYear);
          rs=prepStmt.executeQuery();
          while(rs.next()){
          // pname=rs.getString("pName");
           String d=rs.getString("day");
           String y=rs.getString("month");
           String m=rs.getString("year");
           String t=rs.getString("time");
           String c=rs.getString("cost");
           
             DefaultTableModel model=(DefaultTableModel) Daysearch.searchTable.getModel();
              model.addRow(new Object[]{d,y,m,t,c});
          total=total+Double.parseDouble(c);
            //day.setVisible(true);
         
          }
           Daysearch.dayCost.setText("CurrentDay:  "+total+" Taka only");
       Daysearch.displayDay.setText("Date:"+cal.getTime());
          System.out.println(" "+YEAR+"-"+MONTH+"-"+DAY_OF_MONTH);
      }catch(Exception e){
         // System.out.println("Sell Of Today: "+e);
      }
      
      
     // return amo;
  }
    public void getMonth(){
      try{
          Daysearch day =new Daysearch();
               String query="select day,month,year,time,cost from admintable where  month=? and year=?";
         prepStmt = con.prepareStatement(query);
         prepStmt.setString(1,strMonth);
         prepStmt.setString(2,strYear);
         //prepStmt.setString(2,strYear);
          rs=prepStmt.executeQuery();
          while(rs.next()){
          // pname=rs.getString("pName");
           String d=rs.getString("day");
           String y=rs.getString("month");
           String m=rs.getString("year");
           String t=rs.getString("time");
           String c=rs.getString("cost");
           
             DefaultTableModel model=(DefaultTableModel) Daysearch.searchTable.getModel();
              model.addRow(new Object[]{d,y,m,t,c});
           total=total+Double.parseDouble(c);
            day.setVisible(true);
         
          }
           Daysearch.dayCost.setText("CurrentMonth:  "+total+" Taka only");
       Daysearch.displayDay.setText("Date:"+cal.getTime());
      }catch(Exception e){
         // System.out.println("Sell Of Today: "+e);
      }
  }
      public void getYear(){
      try{
          Daysearch day =new Daysearch();
               String query="select day,month,year,time,cost from admintable where  year=?";
         prepStmt = con.prepareStatement(query);
         prepStmt.setString(1,strYear);
       //  prepStmt.setString(2,strMonth);
       //  prepStmt.setString(3,strYear);
          rs=prepStmt.executeQuery();
          while(rs.next()){
          // pname=rs.getString("pName");
           String d=rs.getString("day");
           String y=rs.getString("month");
           String m=rs.getString("year");
           String t=rs.getString("time");
           String c=rs.getString("cost");
           
             DefaultTableModel model=(DefaultTableModel) Daysearch.searchTable.getModel();
              model.addRow(new Object[]{d,y,m,t,c});
           total=total+Double.parseDouble(c);
            day.setVisible(true);
         
          }
           Daysearch.dayCost.setText("CurrentYear:  "+total+" Taka only");
       Daysearch.displayDay.setText("Date:"+cal.getTime());
      }catch(Exception e){
         // System.out.println("Sell Of Today: "+e);
      }
  }
    
}
