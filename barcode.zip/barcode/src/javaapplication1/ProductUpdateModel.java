/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author mohammed
 */
public class ProductUpdateModel {
    
    public String CatName;
    public String ProName;
    public int ProUnit;
}
